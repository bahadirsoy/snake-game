class Apple {
    constructor(game) {
        this.game = game;

        this.positionX = 5 * gridSize;
        this.positionY = 5 * gridSize;

        this.imageSrc = document.getElementById("apple");
    }

    update() {

    }

    draw(context) {
        context.drawImage(this.imageSrc, this.positionX, this.positionY, gridSize, gridSize);
    }

    setRandomPosition() {
        this.positionX = Math.floor(Math.random() * (colCount - 1)) * gridSize;
        this.positionY = Math.floor(Math.random() * (rowCount - 1)) * gridSize;

        while (true) {
            if (!this.checkPositionOnObstacle() && !this.checkPositionOnSnake()) {

                break;
            } else {
                this.positionX = Math.floor(Math.random() * (colCount - 1)) * gridSize;
                this.positionY = Math.floor(Math.random() * (rowCount - 1)) * gridSize;
            }
        }
    }

    checkPositionOnObstacle() {
        let bool = false;

        if (this.game.obstacles.length === 0) {
            return false;
        }

        this.game.obstacles.forEach(obstacle => {
            if (obstacle.positionX === this.positionX && obstacle.positionY === this.positionY) {
                bool = true;
            }
        })

        return bool;
    }

    checkPositionOnSnake() {
        let bool = false;

        this.game.snake.tail.forEach(t => {
            if (t.positionX === this.positionX && t.positionY === this.positionY) {
                bool = true;
            }
        })

        return bool;
    }

}