//Inıt canvas and context
const canvas = document.getElementById("canvas");
const context = canvas.getContext("2d");

//Get UI elements
const UI_score = document.getElementById("score");
const UI_neededScore = document.getElementById("neededScore");

//Inıt variables
const GAME_WIDTH = 600;
const GAME_HEIGHT = 400;
const gridSize = 20;
const colCount = GAME_WIDTH / gridSize;
const rowCount = GAME_HEIGHT / gridSize;

//Set canvas size
canvas.width = GAME_WIDTH;
canvas.height = GAME_HEIGHT;

//Set game
let game = new Game(0);

//Draw just once
context.fillStyle = "green";
context.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
game.update();
game.draw(context);

//Game loop
let gameLoop = setInterval(() => {
    
    switch (game.gameState) {
        case 0:
            //Set background
            context.fillStyle = "green";
            context.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
            
            game.draw(context);
            break;

        case 1:
            //Set background
            context.fillStyle = "green";
            context.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

            game.update();
            game.draw(context);
            break;

        case 2:

            game.draw(context);
            game.pausePrint(context);

            break;

        case 3:

            game.draw(context);
            game.gameOverPrint(context);

            break;

        case 4:
            game.winPrint();
            break;
    }

    updateScore();
    updateNeededScore();



}, 1000 / 8);



//UI functions

function updateScore(){
    UI_score.textContent = game.snake.tailSize - 4;
}

function updateNeededScore(){
    UI_neededScore.textContent = game.scoreNeeded - game.snake.tailSize + 4;
}