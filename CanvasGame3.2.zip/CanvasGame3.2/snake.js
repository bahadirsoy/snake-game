class Snake {
    constructor(game) {
        this.game = game;

        this.headPositionX = 5 * gridSize;
        this.headPositionY = 2 * gridSize;

        this.speedX = 0;
        this.speedY = 0;

        this.tailSize = 4;
        this.tail = [];

        for (let i = 4; i > 0; i--) {
            this.tail.push({
                positionX: this.headPositionX - i * gridSize,
                positionY: this.headPositionY
            });
        }

        this.date = new Date();
        this.lastMove = this.date.getTime();
        this.moveDelay = 10;

        this.setMoveEvents();
    }

    update() {
        this.headPositionX += this.speedX * gridSize;
        this.headPositionY += this.speedY * gridSize;

        this.checkWallCollision();
        this.checkAppleCollision();
        this.checkSelfCollision();
        this.checkObstacleCollision();

        this.tail.push({
            positionX: this.headPositionX,
            positionY: this.headPositionY
        });

        while (this.tail.length > this.tailSize) {
            //console.log(this.tail.length - 1+" "+this.tailSize);
            this.tail.shift();
        }

        this.date = new Date();

    }

    draw(context) {
        this.tail.forEach(t => {
            if (t.positionX === this.headPositionX && t.positionY === this.headPositionY) {
                context.fillStyle = "rgb(255,165,0)";
                context.fillRect(t.positionX, t.positionY, gridSize - 1, gridSize - 1);
            } else {
                context.fillStyle = "yellow";
                context.fillRect(t.positionX, t.positionY, gridSize - 1, gridSize - 1);
            }
        })
    }

    checkObstacleCollision() {
        this.game.obstacles.forEach(obstacle => {
            if (obstacle.positionX === this.headPositionX && obstacle.positionY === this.headPositionY) {
                this.game.gameState = 3;
            }
        })
    }

    checkSelfCollision() {
        this.tail.forEach(t => {
            if (t.positionX === this.headPositionX && t.positionY === this.headPositionY) {
                this.game.gameState = 3;
            }
        })
    }

    checkAppleCollision() {
        //console.log(`${this.headPositionX}=${this.game.apple.positionX} && ${this.headPositionY}=${this.game.apple.positionY}`)
        if (this.headPositionX === this.game.apple.positionX && this.headPositionY === this.game.apple.positionY) {
            this.tailSize++;
            this.game.apple.setRandomPosition();
        }
    }

    checkWallCollision() {
        if (this.headPositionX < 0) {
            this.headPositionX = (colCount - 1) * gridSize;
        }
        if (this.headPositionX > (colCount - 1) * gridSize) {
            this.headPositionX = 0;
        }
        if (this.headPositionY < 0) {
            this.headPositionY = (rowCount - 1) * gridSize;
        }
        if (this.headPositionY > (rowCount - 1) * gridSize) {
            this.headPositionY = 0;
        }
    }

    setMoveEvents() {
        document.addEventListener("keydown", e => {
            switch (e.keyCode) {
                case 37:

                    /* if (this.game.gameState === 0) {
                        this.game.gameState = 1;
                        this.speedX = -1;
                    } */

                    if (this.speedX != 1) {
                        if (this.date.getTime() >= this.lastMove + this.moveDelay) {
                            this.speedX = -1;
                            this.speedY = 0;
                            this.lastMove = this.date.getTime();
                        }
                    }
                    this.isGameStarted = true;
                    break;

                case 38:
                    if (this.game.gameState === 0) {
                        this.game.gameState = 1;
                        this.speedY = -1;
                    }

                    if (this.speedY != 1) {
                        if (this.date.getTime() >= this.lastMove + this.moveDelay) {
                            this.speedY = -1;
                            this.speedX = 0;
                            this.lastMove = this.date.getTime();
                        }
                    }
                    break;

                case 39:
                    if (this.game.gameState === 0) {
                        this.game.gameState = 1;
                        this.speedX = 1;
                    }

                    if (this.speedX != -1) {
                        if (this.date.getTime() >= this.lastMove + this.moveDelay) {
                            this.speedX = 1;
                            this.speedY = 0;
                            this.lastMove = this.date.getTime();
                        }
                    }
                    this.isGameStarted = true;
                    break;

                case 40:
                    if (this.game.gameState === 0) {
                        this.game.gameState = 1;
                        this.speedY = 1;
                    }

                    if (this.speedY != -1) {
                        if (this.date.getTime() >= this.lastMove + this.moveDelay) {
                            this.speedY = 1;
                            this.speedX = 0;
                            this.lastMove = this.date.getTime();
                        }
                    }
                    this.isGameStarted = true;
                    break;
            }
        })
    }
}