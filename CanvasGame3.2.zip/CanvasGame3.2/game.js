class Game {
    constructor(currentLevel) {

        // 0 => WAITING FOR START
        // 1 => RUNNING
        // 2 => PAUSED
        // 3 => GAME OVER
        // 4 => WIN
        this.gameState = 0;

        this.currentLevel = currentLevel;
        this.scoreNeeded = 10;

        this.init();
        this.setEvents();
    }

    init() {
        this.snake = new Snake(this);
        this.apple = new Apple(this);
        this.obstacles = [];

        this.level = new Level(this);
        this.level.generateLevel(this.level.levels[this.currentLevel]);

        this.gameObjects = [this.snake, this.apple, ...this.obstacles];
    }

    update() {
        this.gameObjects.forEach(object => {
            object.update();
        })

        this.checkScore();

    }

    draw(context) {

        this.gameObjects.forEach(object => {
            object.draw(context);
        })
    }

    checkScore() {
        if (this.snake.tailSize - 4 === this.scoreNeeded) {
            this.currentLevel++;

            if(this.currentLevel > this.level.levels.length - 1){
                this.gameState=4;
                return;
            }

            this.gameOver(this.currentLevel);
        }
    }

    winPrint(){
        context.fillStyle = "red";
        context.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

        context.fillStyle = "white";
        context.font = "60px Arial";
        context.texAlign = "center";
        context.fillText("YOU WIN!", GAME_WIDTH / 2 - 100, GAME_HEIGHT / 2);
    }

    gameOverPrint(context) {
        /* context.fillStyle = "red";
        context.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT); */

        context.fillStyle = "blue";
        context.font = "40px Arial";
        context.texAlign = "center";
        context.fillText("GAME OVER", GAME_WIDTH / 2 - 100, GAME_HEIGHT / 2);

        context.fillStyle = "white";
        context.font = "20px Arial";
        context.fillText("Press SPACEBAR to start a new game", GAME_WIDTH / 2 - 150, GAME_HEIGHT / 2 + 50);
    }

    pausePrint(context) {
        /* context.fillStyle = "gray";
        context.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT); */

        context.fillStyle = "white";
        context.font = "40px Arial";
        context.texAlign = "center";
        context.fillText("PAUSED", GAME_WIDTH / 2 - 85, GAME_HEIGHT / 2);
    }

    gameOver(level) {
        this.gameState = 0;

        //Set game
        game = new Game(level);

        //Draw just once
        context.fillStyle = "green";
        context.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
        game.update();
        game.draw(context);

        context.clearRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
    }

    setEvents() {
        document.addEventListener("keydown", e => {
            switch (e.keyCode) {
                case 27: //ESC
                    if (this.gameState === 1) {
                        this.gameState = 2;
                    } else if (this.gameState === 2) {
                        this.gameState = 1;
                    }
                    break;

                case 32: //SPACEBAR
                    if (this.gameState === 3) {
                        this.gameOver(0);
                    }
                    break;

                case 82:
                    console.log("reset");
                    break;


            }
        })
    }
}