class Obstacle{
    constructor(game, positionX, positionY){
        this.game = game;

        this.positionX = positionX;
        this.positionY = positionY;

        this.imageSrc = document.getElementById("obstacle");
        
    }

    update(){

    }

    draw(context){
        context.drawImage(this.imageSrc, this.positionX, this.positionY, gridSize, gridSize);
    }
}